// Initialize Firebase Cloud Service
export const firebaseConfig = {
    apiKey: "AIzaSyDjnOOscsbY32_gZdw-EsZrvuRNuDmkuSU",
    authDomain: "sanitize-58073.firebaseapp.com",
    databaseURL: "https://sanitize-58073.firebaseio.com",
    projectId: "sanitize-58073",
    storageBucket: "sanitize-58073.appspot.com",
    messagingSenderId: "1046102007239",
    appId: "1:1046102007239:web:48c736eced57170ede8de2"
};

// Old public-facing name: project-1046102007239