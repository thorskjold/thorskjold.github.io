import * as firebase from "firebase";

export default class FirebaseApi {
    // function to upload markers/spots to the cloud database.
    // location, category and image is retrieved via the spot argument (example in AddSpotting)
    // uuid and timestamp is made by firebase.
    uploadSpot(spot, imageUri) {
        // temporary.
        const uploadedObject = {
            uuid: this.getUid(),
            location: new firebase.firestore.GeoPoint(spot.lat, spot.lon),
            category: spot.category,
            timestamp: this.getTimestamp(),
            image: imageUri,
        };

        // actual firebase uploading process
        firebase
            .firestore()
            .collection("spots")
            .add({
                uuid: this.getUid(),
                location: new firebase.firestore.GeoPoint(spot.lat, spot.lon),
                category: spot.category,
                timestamp: this.getTimestamp(),
                image: imageUri,
            })
            .then(function () {
                console.log("Suceessfully uploaded a new spot-marker!");
                return uploadedObject;
            })
            .catch(function (error) {
                console.error("Error writing new spot-marker: ", error);
            });
    }

    // function to get all spots/markers in real time in the cloud database.
    async retrieveAllSpotsAsync() {
        const snapshot = await firebase.firestore().collection("spots").get();
        return snapshot.docs.map((doc) => {
            let spot = doc.data();
            spot.id = doc.id;
            spot.location = {
                latitude: Number(spot.location.latitude.toFixed(6)),
                longitude: Number(spot.location.longitude.toFixed(6)),
            };
            // spot.category = doc.category;
            // spot.timestamp = doc.timestamp;
            // spot.image = doc.image;
            return spot;
        });
    }

    // deletes a single spot from the cloud database.
    // Pre-requiste to know the document name (this is an auto-generated ID for now)
    async deleteSpot(docName) {
        firebase
            .firestore()
            .collection("spots")
            .doc(docName)
            .delete()
            .then(() => {
                console.log("successfully deleted the spot on document: " + docName);
            })
            .catch((error) => {
                console.log(error);
            });
    }

    // Deletes a single image from firebase. Imagename is a timestamp.
    deleteImageFromFirebase(imageName) {
        const dbCollection = "images";
        const dbPath = `${dbCollection}/`;

        let imageRef = firebase.storage().ref(dbPath + imageName);

        imageRef
            .delete()
            .then(() => {
                console.log(`${imageName} has been successfully deleted from firebase.`);
            })
            .catch((error) => {
                console.log(`error while deleting image, with name ${imageName}`, error);
            });
    }

    // Gets a single image from firebase. Imagename is a timestamp.
    retrieveImageFromFirebase(imageName) {
        const dbCollection = "images";
        const dbPath = `${dbCollection}/`;

        let imageRef = firebase.storage().ref(dbPath + imageName);

        imageRef
            .getDownloadURL()
            .then((url) => {
                return url;
            })
            .catch((error) => {
                console.log(`error while retrieving image name: ${imageName}`, error);
            });
    }

    // Uploads an item with a uri (image) to firebase cloud storage
    async uploadItemToFirebaseAsync(uri) {
        const dbCollection = "images";
        const dbPath = `${dbCollection}/${this.getTimestamp()}`;

        const response = await fetch(uri);
        const file = await response.blob();

        let upload = await firebase.storage().ref(dbPath).put(file);
        return await upload.ref.getDownloadURL();
    }

    getProfileImage() {
        return firebase.auth().currentUser.photoURL
    }

    getUserDisplayName() {
        return firebase.auth().currentUser.displayName
        // firebase.auth().onAuthStateChanged(function(user) {
        //     if (user) {
        //         return user.displayName
        //     }
        // })
    }

    getFirestore() {
        return firebase.firestore();
    }

    getUid() {
        return (firebase.auth().currentUser || {}).uid;
    }

    getUserEmail() {
        return firebase.auth().return(firebase.auth().currentUser.email);
    }

    getTimestamp() {
        return Date.now();
    }
}

FirebaseApi.shared = new FirebaseApi();
