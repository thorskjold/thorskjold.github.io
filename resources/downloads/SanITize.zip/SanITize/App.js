import React from "react";
import firebase from "firebase";
import { createAppContainer, createSwitchNavigator } from "react-navigation";
import Login from "./screens/Login";
import LoadingScreen from "./screens/LoadingScreen";
import SignUpScreen from "./screens/SignUpScreen";
import ForgotPasswordScreen from "./screens/ForgotPasswordScreen";
import Home from "./screens/Home";
import Camera from "./screens/Camera";
import { firebaseConfig } from "./config";
import Settings from "./screens/Settings";
import AddSpotting from "./screens/AddSpotting";
import AppNavigator from "./navigation/AppNavigator";

// Safeguard to always get the same Firebase instance!
if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
}

export default class App extends React.Component {
    render() {
        return <AppNavigator />;
    }
}

// const AppSwitchNavigator = createSwitchNavigator({
//     LoadingScreen: LoadingScreen,
//     LoginScreen: Login,
//     ForgotPasswordScreen: ForgotPasswordScreen,
//     SignUpScreen: SignUpScreen,
//     Home: Home,
//     Camera: Camera,
//     SettingsScreen: Settings,
//     AddSpotting: AddSpotting,
// });

// const AppNavigator = createAppContainer(AppSwitchNavigator);
