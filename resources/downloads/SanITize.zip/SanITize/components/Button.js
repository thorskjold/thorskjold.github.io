import React from 'react';
import { StyleSheet, Text, SafeAreaView, TouchableOpacity} from 'react-native';
import Colors from '../utils/styles';
import PropTypes from 'prop-types';

export default class SaniButton extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            color: Colors.blue
        }
    }



    render() {
        const { text } = this.props;
        const { colorStyle } = this.props;
        const { onPress } = this.props;
        return (
            <SafeAreaView style={[styles.container, {backgroundColor: Colors.blue} ]}> 
                <TouchableOpacity style={styles.button} onPress={onPress}>
                    <Text style={{color: '#ffff'}}> {text} </Text>
                </TouchableOpacity>
            </SafeAreaView> 
        );
    }
}


const styles = StyleSheet.create({
    container: {
        display: 'flex',
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: Colors.blue,
        borderRadius: 15,
        height: 60,
        margin: 10,
        
    }, button: {
        justifyContent: "center",
        alignItems: "center",
        width: '100%',
        height: '100%',
        marginLeft: '35%',
        marginRight: '35%'
    }
});