import React, { Component } from "react";
import {
    TouchableOpacity,
    Image,
    StyleSheet,
    View,
    SafeAreaView,
    Text,
    Dimensions,
    RefreshControlComponent,
} from "react-native";
import BottomSheet from "react-native-bottomsheet-reanimated";
import Button from "./Button";
import AppStyles from "../utils/styles";

const Screen = {
    width: Dimensions.get("window").width,
    height: Dimensions.get("window").height,
};

export default class MapDetail extends React.Component {
    unselect = () => {
        const { onUnselect } = this.props;
        onUnselect();
    };

    delete = () => {
        const { spot, onDeleteSpot } = this.props;
        onDeleteSpot(spot.id);
    };

    render() {
        const { spot, navigate } = this.props;

        return (
            <SafeAreaView style={styles.container}>
                {spot ? (
                    <BottomSheet
                        bottomSheerColor="#FFFFFF"
                        ref="BottomSheet"
                        initialPosition={Screen.height * 1.08}
                        snapPoints={[Screen.height * 1.08, Screen.height * 1.5]}
                        isBackDrop={true}
                        isBackDropDismissByPress={false}
                        isRoundBorderWithTipHeader={true}
                        containerStyle={{ backgroundColor: "white" }}
                        tipStyle={{ backgroundColor: AppStyles.blue }}
                        header={
                            <View>
                                <Text>Spotted:</Text>
                                <Text>Kind: {spot.category}</Text>
                                <TouchableOpacity onPress={this.unselect}>
                                    <Text>X</Text>
                                </TouchableOpacity>
                                <Button onPress={this.delete} text="Delete Spot"></Button>
                            </View>
                        }
                        body={
                            <View style={styles.body}>
                                <Image></Image>
                            </View>
                        }
                    />
                ) : (
                    <BottomSheet
                        bottomSheerColor="#FFFFFF"
                        ref="BottomSheet"
                        initialPosition={Screen.height * 1.08}
                        snapPoints={[Screen.height * 1.08]}
                        isBackDrop={true}
                        isBackDropDismissByPress={false}
                        isRoundBorderWithTipHeader={true}
                        containerStyle={{ backgroundColor: "white" }}
                        tipStyle={{ backgroundColor: AppStyles.blue }}
                        header={
                            <View>
                                <Button onPress={() => navigate("Camera")} text="Add Spot"></Button>
                            </View>
                        }
                        body={<View style={styles.body}></View>}
                    />
                )}
            </SafeAreaView>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        paddingTop: 30,
    },
    body: {
        justifyContent: "center",
        alignItems: "center",
    },
    text: {
        fontSize: 20,
        fontWeight: "bold",
        color: AppStyles.blue,
    },
});
