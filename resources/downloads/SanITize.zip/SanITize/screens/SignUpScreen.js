import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { SafeAreaView } from 'react-navigation';
import InputField from '../components/InputField'
import AppStyles from '../utils/styles'
import * as firebase from 'firebase'

export default class SignUpScreen extends React.Component {
    state = { 
        email: '',
        password: '',
        passwordConfirm: '',
    }

    handleEmail = (textInput) => {
        this.setState({email: textInput})
    }

    handlePassword = (textInput) => {
        this.setState({password: textInput})
    }

    handlePasswordConfirm = (textInput) => {
        this.setState({passwordConfirm: textInput})
    }

    handleGoBack = () => {
        this.props.navigation.navigate('LoginScreen')
    }

    handleCreateUser = () => {
        if(this.state.password !== this.state.passwordConfirm) {
            Alert.alert("Passwords do not match!")
            return
        }

        firebase.auth().createUserWithEmailAndPassword(this.state.email, this.state.password)
            .then(() => { 
                
            }, (error) => {
                Alert.alert(error.message)
            })
    }

    render(){
        return (
        <View style={styles.wrapper}>
          <SafeAreaView style={styles.container}>
            <Text style={styles.logo}>Sign up</Text>
            <View style={styles.inputView} >
              <InputField  
                style={styles.inputText}
                isPassword={false}
                placeholder={"Email"}
                value={this.state.email}
                autoCapitalize={"none"}
                placeholderTextColor={AppStyles.grey}
                onChangeText={text => this.handleEmail(text)}/>
            </View>
            <View style={styles.inputView} >
            <InputField  
                style={styles.inputText}
                isPassword={true}
                placeholder={"Password"}
                value={this.state.password}
                autoCapitalize={"none"}
                placeholderTextColor={AppStyles.grey}
                onChangeText={text => this.handlePassword(text)}/>
            </View>
            <View style={styles.inputView} >
            <InputField  
                style={styles.inputText}
                isPassword={true}
                placeholder={"Confirm password"}
                value={this.state.passwordConfirm}
                autoCapitalize={"none"}
                placeholderTextColor={AppStyles.grey}
                onChangeText={text => this.handlePasswordConfirm(text)}/>
            </View>
            <TouchableOpacity style={styles.loginBtn} onPress={() => this.handleCreateUser()}>
              <Text style={styles.loginText}>CREATE USER</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => this.handleGoBack()}>
              <Text style={styles.loginText}>Go back</Text>
            </TouchableOpacity>
            </SafeAreaView>
          </View>
        );
      }
    }
    
    const styles = StyleSheet.create({
        wrapper: {
            flex: 1,
            alignSelf: "stretch",
        },
        container: {
        flex: 1,
        backgroundColor: AppStyles.greyDark,
        alignItems: 'center',
        justifyContent: 'center',
        alignContent: 'stretch',
        
      },
      logo:{
        fontWeight:"bold",
        fontSize:50,
        color: AppStyles.green,
        marginBottom:40
      },
      inputView:{
        width:"80%",
        backgroundColor: 'rgba(255,255,255,0.1)',
        borderRadius:25,
        height:50,
        marginBottom:20,
        justifyContent:"center",
        padding:20
      },
      inputText:{
        height:50,
        color:"white"
      },
      forgot:{
        color:"white",
        fontSize:11
      },
      loginBtn:{
        width:"80%",
        backgroundColor: AppStyles.green,
        borderRadius:25,
        height:50,
        alignItems:"center",
        justifyContent:"center",
        marginTop:15,
        marginBottom:15
      },
      loginText:{
        color:"white"
      }
    });