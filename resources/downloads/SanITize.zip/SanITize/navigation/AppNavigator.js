import React from "react";
import { createAppContainer, createSwitchNavigator } from "react-navigation";
import AddSpotting from "../screens/AddSpotting";
import Home from "../screens/Home";
import SignUpScreen from '../screens/SignUpScreen'
import ForgotPasswordScreen from '../screens/ForgotPasswordScreen'
import Login from '../screens/Login'

import DrawerNavigator from "./DrawerNavigator";

export default createAppContainer(
    createSwitchNavigator({
        LoginScreen: Login,
        ForgotPasswordScreen: ForgotPasswordScreen,
        SignUpScreen: SignUpScreen,
        Main: DrawerNavigator,
        Home: Home,
        AddSpotting: AddSpotting,
    })
);
