# SanITize

### Group 5

Mette, Synne, Thor, Mikkel, Mike and Søren

### Run app

```sh
cd sanitize
npm install
npm start
```
