import React from 'react';
import {View,Text} from 'react-native';
import { createDrawerNavigator } from 'react-navigation-drawer';

import Home from '../screens/Home';
import Profile from '../screens/Profile';
import Settings from '../screens/Settings';
import Camera from '../screens/Camera';
import Login from '../screens/Login';

const DrawerNavigator = createDrawerNavigator({
  Home: Home,
  Profile: Profile,
  Settings: Settings,
  Camera: Camera,
  LogOut: Login, 
});

export default DrawerNavigator;