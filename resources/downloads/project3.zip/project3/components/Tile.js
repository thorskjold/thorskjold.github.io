import React from 'react';
import { StyleSheet, Text, View, Image, TouchableOpacity} from 'react-native';
import Colors from '../utils/styles';
import PropTypes from 'prop-types';
import { deleteSpot } from '../utils/api';
import FirebaseApi from '../utils/FirebaseApi'

export default class Tile extends React.Component {
    constructor(props) {
        super(props);
    }

    getTimeDifference = (dateAsString) => {
        var msDiff = new Date(dateAsString).getTime() - new Date().getTime();    //Future date - current date
        var daysSince = Math.floor((msDiff*-1 ) / (1000 * 60 * 60 * 24));
        return daysSince;
    }

    deleteSpot = async (id) => {
        await FirebaseApi.shared.deleteSpot(id);
        const spots = this.state.spots.filter((spot) => {
            return spot.id !== id;
        });
        this.setState({
            spots,
            selectedSpot: null,
        });
    };

    render() {
        
        const { spot } = this.props;
        const { imageURI } = this.props;
        return (
            <View style={styles.container}> 
                <View style={styles.textView}> 
                    <Text style={styles.boldText}>Category</Text>
                    <Text style={styles.infoText}>{spot.category} </Text>
                    <Text style={styles.boldText}>Spotted</Text>
                    <Text style={styles.infoText}>{this.getTimeDifference(spot.timestamp)} days ago </Text>
                    <TouchableOpacity onPress={() => this.deleteSpot(spot.id)}>
                        <Image style={styles.trash} source={require('../assets/trash.png')}></Image>
                    </TouchableOpacity>
                </View> 
                <View>
                    <Image style={styles.img} source={{uri: imageURI}}></Image>
                </View>

            </View>
        );
    }
}


const styles = StyleSheet.create({
    container: {
        display: 'flex',
        flexDirection: 'row',
        padding: 20,
        justifyContent: "space-around",
        alignItems: 'center',
        backgroundColor: Colors.grey,
        width: '90%',
        borderRadius: 15,
        margin: 10
    }, textView: {
        flex: 1
    }, imgView: {
        flex: 1,
    }, boldText: {
        fontSize: 15,
        fontWeight: 'bold'
    }, infoText: {
        marginBottom: 15
    }, trash: {
        width: 20,
        height: 20,
        marginTop: 20
    }, img: {
        height: 140,
        width: 140,
        resizeMode: 'stretch'
    }
});