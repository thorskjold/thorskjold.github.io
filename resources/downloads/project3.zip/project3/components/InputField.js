import React, {Component} from 'react';
import { StyleSheet, TextInput} from 'react-native';
import PropTypes from 'prop-types';
import AppStyles from '../utils/styles'

export default class InputField extends React.Component {
    static propTypes = {
        isPassword: PropTypes.bool.isRequired, // must be supplied when making an InputField
        isEditable: PropTypes.bool,
        isEmail: PropTypes.bool,
        autoCapitalize: PropTypes.string,
        textColor: PropTypes.string,
        fontSize: PropTypes.number,
        placeholder: PropTypes.string,
        placeholderTextColor: PropTypes.string,
        value: PropTypes.string.isRequired, // must be supplied when making an InputField
        maxLength: PropTypes.number,
        minWidth: PropTypes.number,
        backgroundColor: PropTypes.string,
        style: PropTypes.object,
        onChangeText: PropTypes.func.isRequired, // must be supplied when making an InputField
    }

    // consider to make a password render function and a non-password render function to reduce complexity

    render() {
        if(this.props.isPassword) {
            return(
            <TextInput style={this.props.style || styles.input}
                 textColor={this.props.textColor}
                 placeholder = {this.props.placeholder}
                 placeholderTextColor = {this.props.placeholderTextColor}
                 editable={this.props.isEditable}
                 value={this.props.value} 
                 autoCapitalize={this.props.autoCapitalize}
                 labelFontSize={this.props.fontSize || 12}
                 onChangeText = {this.props.onChangeText}
                 maxLength={this.props.maxLength || 40}
                 backgroundColor={this.props.backgroundColor}
                 secureTextEntry={true} // sensors text input with asterisks
                />
            )
        }
        else {
            return(
                <TextInput style={this.props.style || styles.input}
                textColor={this.props.textColor}
                placeholder = {this.props.placeholder}
                placeholderTextColor = {this.props.placeholderTextColor}
                editable={this.props.isEditable}
                value={this.props.value}
                keyboardType={this.props.isEmail ? 'email-address' : 'default'}
                autoCapitalize={this.props.autoCapitalize}
                labelFontSize={this.props.fontSize || 12}
                onChangeText = {this.props.onChangeText}
                maxLength={this.props.maxLength || 40}
                backgroundColor={this.props.backgroundColor}
                />
            )
        }
    }
}

const styles = StyleSheet.create({
    input: {
        minWidth: 120,
        borderBottomWidth: 1.0,
        paddingLeft: 2,
        textAlign: "left"
    },
});