import sleep from "../utils/sleep";
import spotData from "./mock/spot-data";

const mapSpots = (spot) => {
    const { id, lat, lng, category, timestamp } = spot;

    return {
        id,
        coords: { latitude: lat, longitude: lng },
        category,
        timestamp
    };
};

/**
 * Returns array of spots
 */
export const getSpots = async () => {
    await sleep(500);
    return spotData.results.map(mapSpots);
};

/**
 * Returns a single spot
 */
export const getSpot = async (id) => {
    await sleep(500);
    const spot = spotData.results.find((spot) => spot.id === id);
    return mapSpots(spot);
};

/**
 * Returns array of spot incl. added spot
 */
export const addSpot = async (spot) => {
    await sleep(500);
    spotData.results.push(spot);
    return spotData.results.map(mapSpots);
};

/**
 * Returns array of spots excl. deleted spot
 */
export const deleteSpot = async (id) => {
    await sleep(500);
    const spots = spotData.results.filter((spot) => {
        return spot.id !== id;
    });
    return spots.map(mapSpots);
};
