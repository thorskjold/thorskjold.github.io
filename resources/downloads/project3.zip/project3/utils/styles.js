export default {
    blue: '#007AFF',
    blueDark: '#241E4E',
    grey: '#DEE7E7',
    greyDark: '#1F2934',
    red: '#FF3B30',
    redDark: '#8F0700',
    black: '#181818',
    white: '#FFFFFF',
    green: '#54bd8f',
    greenAccent: '#7DCEAD',
    greenLightest: '#AAE0CB',
};
