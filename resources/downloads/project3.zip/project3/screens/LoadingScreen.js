import React from 'react';
import firebase from 'firebase';
import {
    StyleSheet,
    Text,
    View,
    ActivityIndicator,
    Button,
} from 'react-native';

export default class LoadingScreen extends React.Component {
    componentDidMount() {
        this.checkIfLoggedIn();
    }

    checkIfLoggedIn = () => {
        firebase.auth().onAuthStateChanged((user) => {
            if (user) {
                // user is logged in, navigate to next app screen
                console.log('Loading Screen: User is logged in.');
                this.props.navigation.navigate('Home');
            } // user is not logged in, go back to login screen
            else {
                console.log('Loading Screen: User is not logged in.');
                this.props.navigation.navigate('LoginScreen');
            }
        });
    };

    render() {
        return (
            <View style={styles.container}>
                <ActivityIndicator size="large" />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
});
