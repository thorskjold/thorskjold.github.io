import React from 'react';
import { StyleSheet, Text, View, SafeAreaView } from 'react-native';
import { TouchableOpacity } from 'react-native-gesture-handler';
import AppColors from '../utils/styles';

export default class DummyLoggedIn extends React.Component {
    handlePress = () => {
        this.props.navigation.navigate('Home');
    };

    render() {
        return (
            <View style={styles.container}>
                <SafeAreaView>
                    <Text>Successfully logged in! Welcome to SanITize!</Text>
                    <TouchableOpacity onPress={this.handlePress}>
                        <Text style={styles.backButton}>Go back to Home</Text>
                    </TouchableOpacity>
                </SafeAreaView>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    backButton: {
        marginTop: 50,
        color: AppColors.green,
    },
});
