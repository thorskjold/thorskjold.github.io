import React from "react";
import {
    StyleSheet,
    SafeAreaView,
    Dimensions,
    TouchableOpacity,
    Text,
    Alert,
    ActivityIndicator,
    Image,
    Modal,
    View,
    Vibration,
} from "react-native";
import AppColors from "../utils/styles";
import MapView, { Marker } from "react-native-maps";
import * as Location from "expo-location";
import * as Permissions from "expo-permissions";
import generatedMapStyle from "../utils/googleMapStyle.json";
import MapDetail from "../components/MapDetail";
import store from "../store";
import { getSpots, getSpot, addSpot, deleteSpot } from "../utils/api";
import FireApi from "../utils/FirebaseApi";
import * as firebase from "firebase";
import { getDistance } from "geolib";
import Header from "../components/Header.js";

const Poop = require("../assets/spot-icons/shit.png");
const Trash = require("../assets/spot-icons/trash.png");
const Glass = require("../assets/spot-icons/glass.png");
const Syringe = require("../assets/spot-icons/syringe.png");
const Other = require("../assets/spot-icons/other.png");

export default class Home extends React.Component {
    // I will probably move all location stuff to the map component.
    icons = {
        Poop,
        Trash,
        Glass,
        Syringe,
        Other,
    };

    alerts = {
        Poop: "You're close to poo. Be careful not to step on it.",
        Trash: "You're close to some dropped trash. Be careful not to step on it.",
        Glass: "Your'e close to some broken glass. Be careful not to step on it.",
        Syringe: "Your'e close to a left syringe. Be careful not to step on it.",
        Other: "You might be close to somehing not nice to step on.",
    };

    state = {
        location: null,
        region: null,
        spots: null,
        loading: true,
        error: null,
        selectedSpot: null,
        nearbySpot: null,
        modalVisible: false,
        isMounted: false,
    };

    getClosestSpot(currentCoords) {
        let { spots } = this.state;

        spots.forEach((spot) => {
            spot.currentDistance = getDistance(currentCoords, spot.location, 1);
        });

        spots.sort((spot1, spot2) => {
            if (spot1.currentDistance < spot2.currentDistance) {
                return -1;
            }
            if (spot1.currentDistance > spot2.currentDistance) {
                return 1;
            }
            return 0;
        });

        this.setState({
            spots,
        });
    }

    async componentDidMount() {
        this.setState({ isMounted: true });
        const spots = await FireApi.shared.retrieveAllSpotsAsync();
        this.setState({ spots, loading: false });
        // this.unsubscribe = store.onChange(() => {
        //     if (this.state.isMounted) {
        //         this.setState({
        //             loading: store.getState().isFetchingSpots,
        //             error: store.getState().error,
        //         });
        //     }
        // });

        let { status } = await Permissions.askAsync(Permissions.LOCATION);
        if (status !== "granted") {
            this.setState({
                permission: false,
                errorMessage:
                    "Permission to access location was denied. To use the app, please go to your settings and give permission.",
            });
        } else {
            this.setState({
                permission: true,
                errorMessage: null,
            });
            // To get location updates while in background you'll need to use Location.startLocationUpdatesAsync.
            this.watchId = await Location.watchPositionAsync(
                {
                    accuray: Location.Accuracy.BestForNavigation,
                    timeInterval: 1000,
                    distanceInterval: 1,
                    mayShowUserSettingsDialog: true,
                },
                (currentPosition) => {
                    if (this.state.spots) {
                        this.getClosestSpot({
                            latitude: currentPosition.coords.latitude,
                            longitude: currentPosition.coords.longitude,
                        });

                        if (this.state.spots[0]?.currentDistance <= 5) {
                            this.setState({
                                nearbySpot: this.state.spots[0],
                            });
                            Vibration.vibrate();
                            this.setModalVisible(true);
                        }
                    }

                    this.setState({
                        region: {
                            latitude: currentPosition.coords.latitude,
                            longitude: currentPosition.coords.longitude,
                            latitudeDelta: 0.005,
                            longitudeDelta: 0.005,
                        },
                    });
                }
            );
        }
    }

    componentWillUnmount() {
        // this.unsubscribe();
        if (this.watchId) this.watchId.remove();
        this.state.isMounted = false;
    }

    selectSpot(selectedSpot) {
        this.setState({
            selectedSpot,
        });
    }

    unselectSpot = () => {
        this.setState({
            selectedSpot: null,
        });
    };

    deleteSpot = async (id) => {
        await FireApi.shared.deleteSpot(id);
        const spots = this.state.spots.filter((spot) => {
            return spot.id !== id;
        });
        this.setState({
            spots,
            selectedSpot: null,
        });
    };

    setModalVisible(modalVisible) {
        this.setState({
            modalVisible,
        });
    }

    render() {
        const { loading, spots, region, selectedSpot, permission, errorMessage, modalVisible, nearbySpot } = this.state;

        return (
            <React.Fragment>
                <Header />
                <SafeAreaView style={styles.container}>
                    {nearbySpot ? (
                        <Modal animationType="slide" transparent={true} visible={modalVisible}>
                            <View style={styles.centeredView}>
                                <View style={styles.modalView}>
                                    <Image source={this.icons[nearbySpot.category]} style={{ height: 50, width: 50 }} />
                                    <Text style={styles.modalHeading}>Watch out!</Text>
                                    <Text style={styles.modalText}>{this.alerts[nearbySpot.category]}</Text>
                                    <TouchableOpacity
                                        style={{ ...styles.button, backgroundColor: "#2196F3" }}
                                        onPress={() => this.setModalVisible(false)}
                                    >
                                        <Text style={styles.textStyle}>Dismiss</Text>
                                    </TouchableOpacity>
                                </View>
                            </View>
                        </Modal>
                    ) : null}
                    {loading && <ActivityIndicator size="large" />}
                    {!loading && permission ? (
                        <MapView
                            provider={MapView.PROVIDER_GOOGLE}
                            style={styles.map}
                            initialRegion={region}
                            customMapStyle={generatedMapStyle}
                            showsUserLocation={true}
                        >
                            {spots &&
                                spots.map((spot, index) => (
                                    <Marker
                                        key={index}
                                        coordinate={spot.location}
                                        title={spot.category}
                                        onPress={() => this.selectSpot(spot)}
                                    >
                                        {selectedSpot && spot.id === selectedSpot.id ? (
                                            <Image
                                                source={this.icons[spot.category]}
                                                style={{ height: 50, width: 50 }}
                                            />
                                        ) : (
                                            <Image
                                                source={this.icons[spot.category]}
                                                style={{ height: 30, width: 30 }}
                                            />
                                        )}
                                    </Marker>
                                ))}
                        </MapView>
                    ) : (
                        <Text style={styles.error}>{errorMessage}</Text>
                    )}
                    <MapDetail
                        spot={selectedSpot}
                        onDeleteSpot={this.deleteSpot}
                        onUnselect={this.unselectSpot}
                        navigate={this.props.navigation.navigate}
                    ></MapDetail>
                </SafeAreaView>
            </React.Fragment>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: "center",
    },
    header: {
        flex: 1,
        alignItems: "center",
    },
    backButton: {
        marginTop: 10,
        marginBottom: 10,
        color: AppColors.red,
    },
    map: {
        flex: 10,
        width: Dimensions.get("window").width,
        alignItems: "center",
    },
    mapDetail: {
        flex: 2,
    },
    error: {
        margin: 20,
        textAlign: "center",
    },
    centeredView: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
    },
    modalView: {
        margin: 20,
        backgroundColor: "white",
        borderRadius: 20,
        padding: 35,
        alignItems: "center",
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5,
    },
    button: {
        backgroundColor: "#F194FF",
        borderRadius: 20,
        padding: 10,
        elevation: 2,
    },
    textStyle: {
        color: "white",
        fontWeight: "bold",
        textAlign: "center",
    },
    modalHeading: {
        fontSize: 24,
        marginBottom: 10,
    },
    modalText: {
        textAlign: "center",
        fontSize: 16,
        marginBottom: 15,
    },
});
