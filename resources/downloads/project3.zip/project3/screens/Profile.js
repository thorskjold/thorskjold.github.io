import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { StyleSheet, Text, View, SafeAreaView, Image, ScrollView } from 'react-native';
import Colors from '../utils/styles';
import CustomButton from '../components/Button.js';
import Tile from '../components/Tile.js';
import Header from '../components/Header.js';
import { getSpots, getSpot, addSpot, deleteSpot } from "../utils/api"
import store from "../store";
import FirebaseApi from '../utils/FirebaseApi'

/*
if(spots.uuid === FirebaseApi.shared.getUid) {
    // Load kun spots for denne bruger
}

*/

export default class App extends React.Component {
    onPress = () => { // Proof of concept - The button works!
        console.log("hello");
    }

    state = {
        spots: store.getState().spots,
        spotLength: 1,
        profileName: "Ola Nordmann",
        profileImage: "https://lh4.googleusercontent.com/-oVnThGuc-os/AAAAAAAAAAI/AAAAAAAAAAA/AMZuuckHvN3K7nDfYC6-lkPKTTJWLubcRg/s96-c/photo.jpg",
    };

    async componentDidMount() {
        const spots = await FirebaseApi.shared.retrieveAllSpotsAsync();
        this.useProfileNameFromFirebase();
        this.useProfileImageFromFirebase();
        console.log(spots);
        store.setState({ spots, isFetchingSpots: false });
        this.setState({spotLength: spots.length, spots: spots})
    }

    useProfileNameFromFirebase = () => {
        const userDisplayName = FirebaseApi.shared.getUserDisplayName();

        this.setState({
            profileName: userDisplayName
        })
    }

    useProfileImageFromFirebase = () => {
        const userImage = FirebaseApi.shared.getProfileImage();

        this.setState({
            profileImage: userImage
        })
    }

    render() {
        const spots = this.state.spots;

        return (
            <React.Fragment>
                <Header />
                <SafeAreaView style={styles.container}>
                    <View style={styles.profile}>
                        <Text style={styles.profileText}>{this.state.profileName}</Text>
                        <View style={styles.profileDetails}>
                            <Image style={{width: 40, height: 40}} source={{uri: this.state.profileImage}}></Image>
                            <View style={styles.smallTile}>
                                <Text style={styles.boldText}>Spottings</Text>
                                <Text>{this.state.spotLength}</Text>
                            </View>
                            <View style={styles.smallTile}>
                                <Text style={styles.boldText}>Cleanings</Text>
                                <Text>15</Text>
                            </View>
                        </View>
                    </View>
                    <View style={styles.tiles}>
                        <ScrollView>
                        {spots.map((spot, index) => (
                            // How do I get spot.timestamp ?
                            
                                <Tile spot={spot} key={index} imageURI={spot.image}></Tile>
                            ))}
                        </ScrollView>
                    </View>
                    
                    <CustomButton text="Add trash" colorStyle="#007AFF" onPress={this.onPress} style={styles.button}> </CustomButton>
                    
                </SafeAreaView>
            </React.Fragment>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
    }, profile: {
        height: '18%',
        width: '100%',
        //backgroundColor: Colors.blueDark,
    }, tiles: {
        height: '64%',
        marginLeft: '5%'
    }, profileText: {
        alignSelf: 'center',
        fontSize: 25,
        fontWeight: 'bold',
        marginBottom: 10
    },  profileDetails: {
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'space-around',
        alignItems: 'center'
    }, smallTile: {
        display: 'flex',
        flexDirection: 'column',
        padding: 15,
        justifyContent: "center",
        alignItems: 'center',
        backgroundColor: Colors.grey,
        width: '30%',
        borderRadius: 15,
        margin: 10
    }, boldText: {
        fontSize: 15,
        fontWeight: 'bold'
    }

});
