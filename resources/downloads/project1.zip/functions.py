def read(directory, filename):

  '''
  Imports a dataset from a data file.

  Parameters:
  directory (string): A full path to the destination folder.
  filename (string): A name for the file being read, including file format.

  Returns:
  dataset (dictionary): A dictionary of names for subsets in a dataset, with
  data frames for the subsets as the values.
  '''

  # imports modules neccessary for processing
  import numpy as np
  import pandas as pd

  # defines the dataset dictionary
  dataset = {}
  # defines a list for columns in the dataset
  columns = []
  # defines the subset as an empty string
  subset = ''
  # defiens a list for rows in the subsets in the dataset
  rows = []

  # loops through each line in the data file
  for line in open(directory + filename, encoding = 'ISO-8859-1'):

    # checks if the line is not just a newline, to avoid empty lines
    if line != '\n':

      # removes newlines from the line
      line = line.strip('\n')
      # replaces commas insides double-quotes, to avoid splitting at them
      line = line.replace(', ', '* ')
      # splits the line at commas, into a list
      line = line.split(',')
      # puts back commas that were inside double-quotes in the list
      line = [column.replace('*', ',') if '*' in column else column for column in line]
      # removes double-quotes from the list
      line = [column.replace('"', '') if '"' in column else column for column in line]
      # removes empty elements from the list
      line = [column for column in line if column != ' ']
      # replaces missing values from the dataset with 0
      line = [0 if column == '..' else column for column in line]

      # skips the header
      if len(line) == 1 and columns == []:
        # skips the rest of the loop, and proceeds to the next line
        continue

      # reads the columns
      if len(line) != 1 and columns == []:
        # defines the list of columns as the list for line
        columns = line
        # skips the rest of the loop, and proceeds to the next line
        continue

      # reads the subset
      if len(line) == 1 and rows == []:
        # replaces the empty subset string with the line as a string
        subset = str(line)
        # skips the rest of the loop, and proceeds to the next line
        continue

      # adds lines to array of rows
      if len(line) != 1:
        rows.append(line)
        # skips the rest of the loop, and proceeds to the next line
        continue

      # converts array of rows to a dataframe, and adds it to the dictionary
      if len(line) == 1 and rows != []:
        # converts the list of rows into a Numpy array
        array = np.array(rows)
        # creates a Pandas data frame from the array and list of columns
        dataframe = pd.DataFrame.from_records(
            data = array[:,1:],
            index = array[:,0],
            columns = columns
            )
        # adds the dataframe to the dictionary, with the subset name as the key
        dataset[subset] = dataframe.astype(int)
        # replaces the empty subset string with the line as a string
        # defines the subset as the current line, which is the next subset
        subset = str(line)
        # resets the list of rows
        rows = []
  
  # converts array of rows to a dataframe, and adds it to the dictionary
  if rows != []:
    # converts the list of rows into a Numpy array
    array = np.array(rows)
    # creates a Pandas data frame from the array and list of columns
    dataframe = pd.DataFrame.from_records(
        data = array[:,1:],
        index = array[:,0],
        columns = columns
        )
    # adds the dataframe to the dictionary, with the subset name as the key
    dataset[subset] = dataframe.astype(int)

  # returns the dictionary on the variable assigned to calling the function
  return dataset

def aggregate(dataset, aggregation, sort = 'none'):
    
  '''
  Aggregates the columns of data frames in a dataset.

  Parameters:
  dataset (dictionary): A dictionary of names for subsets in a dataset, with
  data frames for the subsets as the values.
  aggregation (string): An option for how to aggregate the data.
  sort (string): An option for how to sort the data.

  Returns:
  aggregated (dictionary): A dictionary of names for subsets in a dataset, with
  data frames for the subsets as the values.
  '''

  # imports the module neccessary for processing
  import pandas as pd

  # defines lists of valid input options
  aggregations = ['mean', 'sum', 'total', 'min', 'max', 'std']
  sorting = ['none', 'ascending', 'descending']
  
  # checks if the input is not valid
  if aggregation not in aggregations:
    # prints an error message and a list of valid options
    print('You must use an aggregation option from the list below:')
    for choice in aggregations:
      print('-', choice)
    print('\n' + 'Try again by calling the function with a valid aggregation.' + '\n')
  
  # checks if the input is not valid
  if sort not in sorting:
    # prints an error message and a list of valid options
    print('You must use a sorting option from the list below:')
    for choice in sorting:
      print('-', choice)
    print('\n' + 'Try again by calling the function with valid sorting.' + '\n')
  
  # checks if the input is valid
  if aggregation in aggregations and sort in sorting:

    # defines a dictionary for the aggregated dataset
    aggregated = {}

    # loops through the data frames in the dataset
    for dataframe in dataset:

      # transposes the dataset, to aggregate the columns, and not the rows
      transpose = dataset[dataframe].T

      # checks for the aggregation option, and aggregates accordingly
      if aggregation == 'mean':
        result = transpose.mean()
      if aggregation == 'sum':
        result = transpose.sum()
      if aggregation == 'total':
        result = transpose.count()
      if aggregation == 'min':
        result = transpose.min()
      if aggregation == 'max':
        result = transpose.max()
      if aggregation == 'std':
        result = transpose.std()
      
      # checks for the sorting option, and sorts accordingly
      if sort == 'descending':
        result = result.sort_values(ascending = False)
      if sort == 'ascending':
        result = result.sort_values(ascending = True)
      
      # adds the aggregated data frame to the new dictionary
      aggregated[dataframe] = result

  # returns the dictionary on the variable assigned to calling the function
  return aggregated

def removal(dataset):
    
  '''
  Removes rows and columns of only zeros in the data.

  Parameters:
  dataset (dictionary): A dictionary of names for subsets in a dataset, with
  data frames for the subsets as the values.

  Returns:
  removed (dictionary): A dictionary of names for subsets in a dataset, with
  data frames for the subsets as the values.
  '''

  # imports the module neccessary for processing
  import pandas as pd

  # defines a dictionary for the filtered dataset
  removed = {}
  # loops through the data frames in the dataset
  for dataframe in dataset:

    # removes columns with only zeros through indexing and comparison
    vertical = dataset[dataframe].loc[(dataset[dataframe] != 0).any(axis = 1)]
    # removes rows with only zeros through indexing and comparison
    horizontal = vertical.T.loc[(vertical.T != 0).any(axis = 1)]
    # adds a transpose of the filtered data frame to the new dictionary
    removed[dataframe] = horizontal.T
  
  # returns the dictionary on the variable assigned to calling the function
  return removed

def combine(dataset):

  '''
  Combines indices of data frames in a dataset, into new data frames.

  Parameters:
  dataset (dictionary): A dictionary of names for subsets in a dataset, with
  data frames for the subsets as the values.

  Returns:
  combined (dictionary): A dictionary of names for subsets in a dataset, with
  data frames for the subsets as the values.
  '''

  # imports modules neccessary for processing
  import numpy as np
  import pandas as pd

  # defines the index of the first data frame in the dataset
  index = dataset[list(dataset.keys())[0]].index
  # defines the columns of the first data frame in the dataset
  columns = dataset[list(dataset.keys())[0]].columns
  # creates a 3-dimensional Numpy array of values for all subsets in the dataset
  array = np.array([dataset[dataframe].values for dataframe in dataset])

  # defines a dictionary for the combined dataset
  combined = {}
  # loops through the indices of the index for the dataset
  for i in range(len(index)):
    # creates a data frame with values of the index across all dimensions,
    # an index of the keys from the dataset, and the same columns as the dataset
    dataframe = pd.DataFrame.from_records(
    data = array[:,i,:],
    index = list(dataset.keys()),
    columns = columns
    )
    # adds the new data frame to the dictionary, with its old index as the key
    combined[index[i]] = dataframe
  
  # returns the dictionary on the variable assigned to calling the function
  return combined

def visualize(dataset, chart):

  '''
  Creates charts to visualize data frames.

  Parameters:
  dataset (dictionary): A dictionary of names for subsets in a dataset, with
  data frames for the subsets as the values.
  chart (string): An option for how to chart the data.
  '''

  # imports modules neccessary for processing
  import numpy as np
  import pandas as pd
  import matplotlib.pyplot as plt

  # defines a list of valid input options
  charts = ['line', 'scatter', 'stacked', 'pie']

  # checks if the input is not valid
  if chart not in charts:
    # prints an error message and a list of valid options
    print('You must use a chart option from the list below:')
    for choice in charts:
      print('-', choice)
    print('\n' + 'Try again by calling the function with a valid chart.' + '\n')
  
  # checks if the input is valid
  if chart in charts:
    
    # loops through the data frames in the dataset
    for dataframe in dataset:

      # checks if the chart option is for a line chart
      if chart == 'line':
        # transposes the data frame
        transpose = dataset[dataframe].T
        # defines a Matplotlib figure with the given size
        plt.figure(figsize = (15,5))
        # plots the lines on the figure
        plt.plot(transpose)
        # defines the legend of chart as the index, and its location
        plt.legend(
            dataset[dataframe].index,
            bbox_to_anchor = (1.04,0.5),
            loc = "center left",
            borderaxespad = 0
            )

      # checks if the chart option is for a scatter chart
      if chart == 'scatter':
        # defines a Matplotlib figure with the given size
        plt.figure(figsize = (20,5))
        # loops through the columns in the dataframe
        for c in dataset[dataframe].columns:
          # adds the points for the values in the columns to the figure
          plt.scatter(dataset[dataframe].index, dataset[dataframe][c])
        # defines the legend of chart as the columns, and its location
        plt.legend(
            dataset[dataframe].columns,
            bbox_to_anchor = (1.04,0.5),
            loc = "center left",
            borderaxespad = 0
            )

      # checks if the chart option is for a stacked bar chart
      if chart == 'stacked':
        # defines a Matplotlib figure with the given size
        plt.figure(figsize = (10,5))
        # transposes the data frame
        transpose = dataset[dataframe].T
        # defines a list of positions for stacking the bars
        previous = [0 for value in dataset[dataframe].columns]
        # loops through the indices in the data frame
        for i in dataset[dataframe].index:
          # adds the bars to the figure, at the position of the previous loop
          plt.bar(dataset[dataframe].columns, transpose[i], bottom = previous)
          # adds the values of the bars as positions for the next loop
          previous += transpose[i]
        # defines the legend of chart as the index, and its location
        plt.legend(
            dataset[dataframe].index,
            bbox_to_anchor = (1.04,0.5),
            loc = "center left",
            borderaxespad = 0
            )
      
      # checks if the chart option is for a pie chart
      if chart == 'pie':
        # defines a Matplotlib figure with the given size
        plt.figure(figsize = (7,7))
        # adds the values of the data frame as slices to a pie chart
        plt.pie(
            dataset[dataframe].values,
            autopct = '%1.1f%%'
            )
        # defines the legend of chart as the index, and its location
        plt.legend(
            dataset[dataframe].index,
            bbox_to_anchor = (1.04,0.5),
            loc = "center left",
            borderaxespad = 0
            )
      
      # defines the chart title
      plt.title(dataframe)
      # rotates the labels on the x-axis
      plt.xticks(rotation = 90)
      # shows the chart
      plt.show()